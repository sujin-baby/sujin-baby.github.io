/* 상품 위치 찾기 (크롬 확장 프로그램)
   쿠팡 (1.6.0, 11/1): 확장이 쿠팡 검색 화면을 혼자 여는 건 쿠팡이 막음(금요일과 같은 코드도 11/1 'Access Denied' → 확장 코드 밖 원인).
     그래서 네이버처럼: 상품 페이지(또는 생성기 [자동 가져오기]) → 상품 정보·썸네일만. 검색은 사람이 열고(생성기 [쿠팡에서 검색]),
     검색 화면에서 아이콘(Alt+Shift+F) → 그 화면만 읽어서 몇 페이지인지 생성기로. 확장이 쿠팡 검색 주소를 열거나 넘기지 않음
   네이버는 자동으로 여러 페이지를 넘기면 '쇼핑 서비스 접속이 일시적으로 제한' 화면으로 막아서(10/16 실제로 막힘) 자동 넘기기를 안 함:
     상품 페이지에서 아이콘 → 상품 정보·썸네일 + 대표 키워드 검색 탭을 엶 → 그 화면만 읽어서 상품을 찾아 표시
     없으면 [다음 페이지] [가격 넣고 검색] [다음 키워드] 단추 (사람이 한 번 누를 때 한 화면만) */
const VERSION = chrome.runtime.getManifest().version;
const VER_URL = "https://raw.githubusercontent.com/sujin-baby/sujin-baby.github.io/refs/heads/claude/tasting-group-notice-automation-1x1kur/ori/ext/manifest.json";
const MUA = "Mozilla/5.0 (iPhone; CPU iPhone OS 17_5 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.5 Mobile/15E148 Safari/604.1";
const MAXP = 5;
const sleep = ms => new Promise(r => setTimeout(r, ms));
let busy = false, busySince = 0, cancel = false, work = null;

chrome.action.onClicked.addListener(tab => { start(tab); });
/* ---------- 생성기와 주고받기 (gen.js, 사용자 요청 10/20) ----------
   생성기 화면이 열려 있으면 결과(복사하는 글)와 진행 상황을 생성기로 바로 보냄 → 붙여넣기 없이 칸이 채워짐
   생성기 [자동 가져오기]: 상품 페이지를 뒤에서 열고 아이콘을 누른 것처럼 돌림 */
let genT = null, autoTab = 0;
async function genTarget() { if (genT) return genT; const o = await chrome.storage.session.get("genT").catch(() => ({})); return (genT = o.genT || null); }
async function pushGen(m) { const g = await genTarget(); if (!g) return; try { await chrome.tabs.sendMessage(g.tabId, Object.assign({ type: "plPush" }, m), { frameId: g.frameId }); } catch (e) {} }
const setGen = sender => { genT = { tabId: sender.tab.id, frameId: sender.frameId || 0 }; chrome.storage.session.set({ genT: genT }).catch(() => {}); };
chrome.runtime.onMessage.addListener((m, sender) => {
  if (!m || !sender.tab) return;
  if (m.type === "plGenHere") setGen(sender);
  else if (m.type === "plResult") { pushGen({ text: m.text }); if (!m.shot) oyThumb(m.text); }
  else if (m.type === "plShot") shotRect(sender.tab.id, m.rc, { name: m.name, pid: m.pid }).then(r => r && pushGen({ status: r.t })).catch(e => { self.__shotErr = String((e && e.message) || e); pushGen({ status: "캡처 저장 실패: " + self.__shotErr }); });
  else if (m.type === "plStatus") pushGen({ status: m.text });
  else if (m.type === "plAuto" && m.url) { setGen(sender); (m.plt ? autoOpened(m.url, sender.tab, m.plt) : autoRun(m.url, sender.tab)).catch(e => pushGen({ status: "멈췄어요: " + ((e && e.message) || e) })); }
});
/* 올리브영(oy.js) 결과의 썸네일도 다운로드 폴더에 저장 (쿠팡·네이버와 같은 곳, 상품마다 한 번) */
let oyThumbDone = "";
function oyThumb(text) {
  const g = k => ((String(text || "").match(new RegExp("^" + k + "\\s*[:：]\\s*(.+)$", "m")) || [])[1] || "").trim();
  const img = g("썸네일"), pid = g("상품번호");
  if (!/^https?:\/\//.test(img) || !pid || oyThumbDone === pid) return;
  oyThumbDone = pid;
  saveThumb({ img: img, name: g("상품명"), pid: pid }).then(r => pushGen({ status: r.t }));
}
async function autoRun(url, gt) {
  if (busy && Date.now() - busySince < 12 * 60000) { pushGen({ status: "이미 찾는 중이에요. 끝나고 다시 눌러 주세요." }); return; }
  /* 1.7.0: 쿠팡은 확장이 탭을 열지 않음(확장이 연 쿠팡 탭은 쿠팡이 바로 막음). 예전 생성기에서 누른 거면 새로고침 안내 */
  if (/coupang\.com/i.test(String(url))) { pushGen({ status: "생성기를 새로고침(⌘R)한 뒤 다시 눌러 주세요. 쿠팡은 이제 생성기가 직접 열어요 (확장 1.7.0)" }); return; }
  pushGen({ status: "상품 페이지 여는 중…" });
  await keepFn(fnOf(String(url).split("#")[1] || ""));   /* 단축 링크는 넘어가며 #을 버려서 미리 기억 */
  const t = await chrome.tabs.create({ url: url, active: false, windowId: gt.windowId, index: gt.index + 1 });
  autoTab = t.id;
  try {
    /* 단축 링크(link.coupang.com 등)가 상품 페이지로 넘어갈 때까지 (최대 40초) */
    let tab = t;
    for (let i = 0; i < 80; i++) { await sleep(500); tab = await chrome.tabs.get(t.id); if (tab.status === "complete" && /\/products\/\d+|goodsNo=|toss\.shopping\/i\/|shopping-discovery/i.test(tab.url || "")) break; }
    await sleep(1500);
    tab = await chrome.tabs.get(t.id);
    if (/oliveyoung\.co\.kr/.test(tab.url || "")) return await autoOy(tab);
    if (/toss\.(shopping|im)/.test(tab.url || "")) { await chrome.scripting.executeScript({ target: { tabId: tab.id }, files: ["oy.js"] }); return; }   // 토스: 상품 정보만 (검색 순위는 토스 앱 안이라 못 찾음)
    if (!/\/products\/\d+/.test(tab.url || "")) { pushGen({ status: "상품 페이지가 안 열렸어요. 열린 탭을 확인해 주세요." }); await chrome.tabs.update(t.id, { active: true }); return; }
    const isNv = /naver\.com/.test(tab.url || "");
    const out = await start(tab);
    /* 쿠팡: 끝나면 상품 탭 닫음 (결과는 생성기에). 네이버: 검색 탭이 따로 열려서 상품 탭만 닫음. 못 찾으면 상품 탭을 보여 줌 */
    if (out || isNv) chrome.tabs.remove(t.id).catch(() => {});
    else chrome.tabs.update(t.id, { active: true }).catch(() => {});
  } finally { autoTab = 0; }
}
/* 쿠팡 (1.7.0, 11/1): 생성기가 사람 클릭으로 연 상품 탭(주소 # 뒤 plt=표시)을 찾아서, 다 뜨면 읽고 닫음. 확장은 쿠팡 주소를 열거나 새로고침하지 않음.
   이유: 쿠키를 지운 직후에도 확장이 연 쿠팡 탭은 바로 '사용권한 없음', 사람이 연 탭은 열림(10/31 20:33, 11/1 12:02·15:58) */
async function autoOpened(url, gt, plt) {
  if (busy && Date.now() - busySince < 12 * 60000) { pushGen({ status: "이미 찾는 중이에요. 끝나고 다시 눌러 주세요. (방금 열린 쿠팡 탭은 닫아 주세요)" }); return; }
  pushGen({ status: "생성기가 연 쿠팡 상품 탭을 기다리는 중…" });
  await keepFn(fnOf(String(url).split("#")[1] || ""));
  const mark = "plt=" + plt;
  let tid = 0;
  for (let i = 0; i < 30 && !tid; i++) {
    const all = await chrome.storage.session.get(null).catch(() => ({}));
    const k = Object.keys(all).find(x => /^hash_\d+$/.test(x) && all[x] && String(all[x].h || "").indexOf(mark) !== -1);
    if (k) tid = Number(k.slice(5));
    if (!tid) { const ts = await chrome.tabs.query({}).catch(() => []); const t = ts.find(x => String(x.url || x.pendingUrl || "").indexOf(mark) !== -1); if (t) tid = t.id; }
    if (!tid) await sleep(500);
  }
  if (!tid) { pushGen({ status: "쿠팡 상품 탭이 안 열렸어요 (크롬이 새 탭을 막았을 수 있어요). [자동 가져오기]를 다시 눌러 주세요." }); return; }
  autoTab = tid;
  try {
    let tab = await chrome.tabs.get(tid);
    for (let i = 0; i < 80; i++) { if (tab.status === "complete" && /\/products\/\d+/.test(tab.url || "")) break; await sleep(500); tab = await chrome.tabs.get(tid); }
    await sleep(1500);
    tab = await chrome.tabs.get(tid);
    if (!/\/products\/\d+/.test(tab.url || "")) { pushGen({ status: "쿠팡 상품 페이지가 안 열렸어요. 열린 탭을 확인해 주세요." }); return; }
    const out = await start(tab);
    /* 읽었으면 탭 닫고 생성기로. 못 읽었으면(차단 화면 등) 탭을 그대로 둬서 보이게 */
    if (out) { chrome.tabs.remove(tid).catch(() => {}); if (gt && gt.id) chrome.tabs.update(gt.id, { active: true }).catch(() => {}); }
  } finally { autoTab = 0; }
}
/* 올리브영: 상품 페이지에서 oy.js(상품 정보) → 같은 탭을 검색 화면으로 → oy.js(몇 번째). 결과는 oy.js가 생성기로 보냄. 탭은 분홍 테두리 확인용으로 둠 */
async function autoOy(tab) {
  const tid = tab.id;
  await chrome.scripting.executeScript({ target: { tabId: tid }, files: ["oy.js"] });
  await sleep(800);
  const [r] = await chrome.scripting.executeScript({ target: { tabId: tid }, func: () => window.__plOySearch || "" });
  const su = r && r.result;
  if (!su) { pushGen({ status: "올리브영 상품 정보를 못 읽었어요. 열린 탭을 확인해 주세요." }); await chrome.tabs.update(tid, { active: true }); return; }
  pushGen({ status: "올리브영 검색 화면에서 찾는 중…" });
  const p = waitComplete(tid, 30000); await chrome.tabs.update(tid, { url: su }); await p;
  await sleep(1500);
  await chrome.scripting.executeScript({ target: { tabId: tid }, files: ["oy.js"] });
}
/* 결과 상자의 단추 */
chrome.runtime.onMessage.addListener((m, sender) => {
  if (!m || m.type !== "act" || !sender.tab) return;
  if (m.act === "cancel") { cancel = true; closeWork(); ui(sender.tab.id, { title: "멈췄어요", msg: "다시 하려면 아이콘을 누르세요." }); return; }
  naverAct(sender.tab, m.act).catch(e => ui(sender.tab.id, { title: "멈췄어요", msg: "오류: " + ((e && e.message) || e) }));
});
/* 생성기 [상품 페이지 열기]로 연 탭: 주소 뒤 #kw=…&pr=… (의뢰서 키워드)를 탭마다 기억해 둠.
   쿠팡 단축 링크(link.coupang.com)가 상품 페이지로 넘어가면서 # 뒤를 버려서 (10/18 '런치버스 미니 텀블러' 대신 추천 키워드로 찾음) */
const hashOf = u => { const h = String(u || "").split("#")[1] || ""; return /(?:^|&)(kw|plt)=/.test(h) ? h : ""; };
const pidOf = u => (String(u || "").match(/\/(?:vp|vm)\/products\/(\d+)|\/products\/(\d+)/) || []).slice(1).find(Boolean) || "";
async function keepHash(id, u) {
  const k = "hash_" + id, h = hashOf(u);
  if (h) { await chrome.storage.session.set({ [k]: { h: h, pid: pidOf(u) } }); return; }
  const o = (await chrome.storage.session.get(k))[k]; if (!o) return;
  const pid = pidOf(u); if (!pid) return;
  if (!o.pid) { o.pid = pid; await chrome.storage.session.set({ [k]: o }); }
  else if (o.pid !== pid) await chrome.storage.session.remove(k);   /* 다른 상품으로 옮겨 가면 잊음 */
}
chrome.tabs.onCreated.addListener(t => { keepHash(t.id, t.pendingUrl || t.url).catch(() => {}); });
chrome.tabs.onUpdated.addListener((id, ch) => { if (ch.url) keepHash(id, ch.url).catch(() => {}); });
chrome.tabs.onRemoved.addListener(id => { chrome.storage.session.remove("hash_" + id).catch(() => {}); });
async function tabHash(tab) {
  const h = hashOf(tab.url); if (h) return h;
  const k = "hash_" + tab.id, o = (await chrome.storage.session.get(k).catch(() => ({})))[k];
  return o && (!o.pid || o.pid === pidOf(tab.url)) ? o.h : "";
}
self.__test = async () => { const [t] = await chrome.tabs.query({ active: true, lastFocusedWindow: true }); return start(t); };

async function start(tab) {
  if (busy && Date.now() - busySince < 12 * 60000) { await ui(tab.id, { title: "이미 찾는 중이에요", msg: "끝나면 결과가 원래 상품 페이지에 떠요. 멈추고 새로 하려면 아래 단추.", actions: [{ label: "멈추기", act: "cancel", color: "#a33" }] }); return; }
  busy = true; busySince = Date.now(); cancel = false;
  const ka = setInterval(() => chrome.runtime.getPlatformInfo(() => {}), 20000);   /* 오래 걸려도 확장 프로그램이 잠들지 않게 */
  try { return await run(tab); }
  catch (e) {
    const m = String((e && e.message) || e);
    await ui(tab.id, { title: "멈췄어요", msg: /No tab|No window|closed/i.test(m) ? "찾는 창을 닫아서 멈췄어요. 아이콘을 다시 눌러 주세요." : "오류: " + m });
  } finally { busy = false; clearInterval(ka); await closeWork(); }
}

/* ---------- 화면 안 코드 부르기 ---------- */
async function call(tabId, name, args) {
  let err = null;
  for (let i = 0; i < 4; i++) {
    try {
      await chrome.scripting.executeScript({ target: { tabId: tabId }, files: ["page.js"] });
      const [r] = await chrome.scripting.executeScript({ target: { tabId: tabId }, func: (n, a) => window.__PL[n].apply(null, a), args: [name, args || []] });
      return r ? r.result : null;
    } catch (e) { err = e; if (/No tab|No window/i.test(String(e && e.message))) throw e; await sleep(1500); }
  }
  throw err;
}
const ui = (tabId, s) => { if (s && s.title) pushGen({ status: s.title + (s.msg ? " · " + String(s.msg).split("\n")[0] : "") }); return call(tabId, "box", [s]).catch(() => null); };

/* ---------- 키워드 추천 (생성기와 같은 규칙) ----------
   네추럴라이즈 플래티넘 오메가3 1100 1,202mgx180캡슐 → 오메가3 | 플래티넘 오메가3 | 네추럴라이즈 오메가3 */
const KW_STOP = /^(탈부착식|탈부착|착붙는|무타공|세라믹|코팅|프리미엄|고급|대용량|소용량|회전|포함|정품|국내산|수입산|신상|신상품|인기|추천|최신|업그레이드|스마트|터치|겨울|여름|봄|가을|방한|보온보냉|보온|보냉|세척솔|대시보드|특가|증정|무료배송|1\+1|세트|단품|미니|슬림|휴대용|접이식|없습니다|없음|오류|권한|사용권한|페이지)$/;
function suggest(pname) {
  const raw = String(pname || "").replace(/\(.*$/, "").replace(/\[[^\]]*\]/g, " ");
  const dash = raw.split(/\s+-\s+/);
  let toks = dash[0].split(/[\s,]+/).map(t => t.trim()).filter(Boolean);
  const brand = toks.length >= 3 ? toks[0] : "";
  if (brand) toks = toks.slice(1);
  const spec = t => /^\d|\d+(mg|g|kg|ml|l|개|캡슐|정|매|p|도|cm|mm|인치|w)\b|x\d/i.test(t) && !/^[가-힣a-z]+\d+$/i.test(t);
  const isMod = t => /(는|한|된|용)$/.test(t) && t.length <= 4;
  const cand = toks.filter(t => !spec(t) && !KW_STOP.test(t) && !isMod(t) && t.length >= 2);
  const mods = toks.filter(t => /용$/.test(t) && t.length <= 4);
  const cat = dash[1] ? dash[1].split(/[\/,]/)[0].trim() : "";
  const tail = t => t.slice(-3);
  const rep = cand.filter(t => t.length >= 4 && cand.some(u => u !== t && u.length >= 4 && tail(u) === tail(t)));
  let main;
  if (rep.length) main = rep[0];
  else if (cat && cat.length >= 2 && !spec(cat) && !/일반|기타/.test(cat)) main = cat;
  else main = cand.slice(0, 4).pop() || toks[0] || "";
  const alts = rep.filter(t => t !== main);
  const out = [main];
  const add = s => { s = s.trim(); if (s && out.indexOf(s) === -1) out.push(s); };
  alts.forEach(add);
  mods.forEach(m => { add(m + " " + main); alts.forEach(a => add(m + " " + a)); });
  cand.filter(t => t !== main && alts.indexOf(t) === -1 && mods.indexOf(t) === -1).slice(0, 2).forEach(t => add(t + " " + main));
  if (brand) add(brand + " " + main);
  return out.filter(Boolean).slice(0, 4);
}

/* ---------- 검색 주소 ---------- */
function urlFor(site, dev, k, f, p, P) {
  const q = encodeURIComponent(k);
  let u;
  if (site === "coupang") {
    u = dev === "pc" ? "https://www.coupang.com/np/search?q=" + q + "&channel=user&listSize=36&page=" + p : "https://m.coupang.com/nm/search?q=" + q + (p > 1 ? "&page=" + p : "");
    if (f) u += "&isPriceRange=true&minPrice=" + P.lo + "&maxPrice=" + P.hi;
  } else {
    u = (dev === "pc" ? "https://search.shopping.naver.com/search/all?query=" + q + "&pagingIndex=" + p + "&pagingSize=40" : "https://msearch.shopping.naver.com/search/all?query=" + q + (p > 1 ? "&pagingIndex=" + p : ""));
    if (f) u += "&minPrice=" + P.lo + "&maxPrice=" + P.hi;
  }
  return u;
}
/* 가격 필터를 화면에서 넣은 뒤의 주소로 다음 페이지 */
function pageOf(base, site, dev, p) {
  const u = new URL(base);
  if (site === "coupang") u.searchParams.set("page", p);
  else { u.searchParams.set("pagingIndex", p); if (dev === "pc") u.searchParams.set("pagingSize", "40"); }
  return u.href;
}
const sameKeys = (a, b) => !!a && !!b && a.length > 0 && a.join("|") === b.join("|");

/* ---------- 찾는 창 ---------- */
function waitComplete(tabId, ms) {
  return new Promise(res => {
    let t = null;
    const done = () => { clearTimeout(t); chrome.tabs.onUpdated.removeListener(l); res(); };
    function l(id, ch) { if (id === tabId && ch.status === "complete") done(); }
    chrome.tabs.onUpdated.addListener(l);
    t = setTimeout(done, ms);
  });
}
async function openWork() {
  const w = await chrome.windows.create({ url: "about:blank", type: "popup", width: 1280, height: 900, focused: true });
  work = { winId: w.id, tabId: w.tabs[0].id, dbg: false, dnr: false };
}
async function nav(url) {
  if (cancel) throw new Error("멈춤");
  if (/coupang\.com/.test(url)) await sleep(700 + Math.random() * 1300);
  /* 네이버는 너무 빨리 넘기면 보안 확인을 띄워서 사람처럼 1~2.5초 쉬고 */
  if (/naver\.com/.test(url)) await sleep(1000 + Math.random() * 1500);
  work.lastUrl = url;
  const p = waitComplete(work.tabId, 25000);
  await chrome.tabs.update(work.tabId, { url: url });
  await p;
}
async function closeWork() {
  if (!work) return;
  await mobile(false).catch(() => {});
  try { await chrome.windows.remove(work.winId); } catch (e) {}
  work = null;
}
/* 모바일로 보이게: 개발자 도구의 기기 모드와 같은 방법(아이폰 화면). 안 되면 주소 요청만 아이폰으로 */
async function mobile(on) { /* 1.6.0: 쿠팡 자동 검색을 안 해서 안 씀. 예전 chrome.debugger 폰 흉내는 지움(debugger 권한도 뺌) */ }

/* ---------- 화면 읽기 (보안 확인이 뜨면 사람이 풀 때까지 기다렸다가 이어서) ---------- */
let curProg = async () => {};
async function scanW(o) {
  let s = await call(work.tabId, "scan", [o]).catch(e => ({ error: String((e && e.message) || e), n: 0, keys: [] }));
  if (!s || s.error) { await sleep(2500); s = await call(work.tabId, "scan", [o]).catch(e => ({ error: String((e && e.message) || e), n: 0, keys: [] })); }   /* 화면이 아직 바뀌는 중이었으면 한 번 더 */
  if (!s) { const tb = await chrome.tabs.get(work.tabId).catch(() => null); s = { error: "빈 결과", snip: tb ? (tb.title || "") + " " + tb.url : "", n: 0, keys: [] }; }
  if (s && s.blocked) {
    work.blockSnip = s.snip || "";
    if (!(await waitHuman())) return s;
    await nav(work.lastUrl);
    s = await call(work.tabId, "scan", [o]).catch(e => ({ error: String((e && e.message) || e), n: 0, keys: [] }));
  }
  return s;
}
const HARD_BLOCK = /일시적으로\s*제한|접속이\s*(제한|불가)|Access Denied/i;
async function waitHuman() {
  if (HARD_BLOCK.test(work.blockSnip || "")) return false;   /* 접속 제한은 풀 수 있는 확인 화면이 아님 → 바로 멈춤 */
  try { await chrome.windows.update(work.winId, { focused: true, state: "normal" }); } catch (e) {}
  const msg = "쇼핑몰이 보안 확인을 띄웠어요. 이 창에서 확인을 풀어 주세요. 풀면 자동으로 이어서 찾아요 (창은 닫지 마세요)";
  await call(work.tabId, "banner", [msg]).catch(() => {});
  await curProg("⚠ 쇼핑몰이 보안 확인을 띄웠어요.\n앞에 뜬 작은 창에서 확인을 풀어 주시면 자동으로 이어서 찾아요. (5분까지 기다려요)");
  for (let i = 0; i < 150; i++) {
    await sleep(2000);
    const st = await call(work.tabId, "state").catch(() => null);
    if (st && !st.blocked) { await sleep(1500); return true; }
    if (i % 5 === 4) await call(work.tabId, "banner", [msg]).catch(() => {});
  }
  return false;
}

/* ---------- 한 키워드(+가격) 단계 찾기 ---------- */
async function look(ctx, dev, k, f) {
  const { site, info, P, prog } = ctx;
  const o = { pid: info.pid, nm: info.name, st: info.seller, lo: f ? P.lo : 0, hi: f ? P.hi : 0, scroll: dev === "mo", max: 200 };
  const lab = (dev === "pc" ? "PC " : "모바일 ") + (f ? "'" + k + "' + 가격" : "'" + k + "'");
  const plainKey = dev + "|" + k;
  if (f && !ctx.plain[plainKey]) {
    /* 가격 필터가 들어갔는지 보려고 필터 없는 첫 화면을 먼저 봐 둠 */
    await prog(lab + " 준비 중…");
    await nav(urlFor(site, dev, k, false, 1, P));
    const s0 = await scanW({ pid: info.pid, nm: info.name, st: info.seller, quick: true });
    if (s0 && s0.keys) ctx.plain[plainKey] = s0.keys;
  }
  await prog(lab + " 1페이지 확인 중…");
  await nav(urlFor(site, dev, k, f, 1, P));
  let s = await scanW(o);
  if (!s) return { err: "화면을 못 읽음" };
  if (s.blocked) return { blocked: true };
  if (s.error) return { err: "화면 읽기 오류(" + s.error + ") 화면: " + (s.snip || "") };
  if (f) {
    const plain = ctx.plain[plainKey];
    let applied = s.priceChip || (plain && !sameKeys(plain, s.keys));
    if (!applied && site === "naver" && dev === "pc") {
      /* 주소로 가격이 안 들어가면 화면의 가격 칸에 직접 넣고 검색 */
      await nav(urlFor(site, dev, k, false, 1, P));
      await scanW({ pid: info.pid, nm: info.name, st: info.seller });
      const ok = await call(work.tabId, "priceUI", [P.lo, P.hi]);
      if (ok) { await sleep(3000); s = await scanW(o); applied = s && (s.priceChip || (plain && !sameKeys(plain, s.keys))); }
    }
    if (!applied) return { nofilter: true };
  } else ctx.plain[plainKey] = s.keys;
  if (s.n === 0) return { page: 0, seen: 0, empty: true, snip: s.noResult ? "" : s.snip };
  const base = s.url;
  if (dev === "mo") {
    if (s.hit >= 0) { if (!ctx.shot) ctx.shot = await shotHit(work.tabId, s.hit, info); return { pos: s.hit + 1, org: s.org, how: s.how, scroll: true }; }
    /* 계속 내려가지 않고 페이지로 나뉘는 화면이면 다음 페이지 */
    let seen = s.n, prev = s.keys;
    for (let p = 2; p <= MAXP && s.n <= 60; p++) {
      await prog(lab + " " + p + "페이지 확인 중…");
      await nav(pageOf(base, site, dev, p));
      s = await scanW(o);
      if (!s || s.blocked || s.n === 0 || sameKeys(s.keys, prev)) break;
      if (s.hit >= 0) { if (!ctx.shot) ctx.shot = await shotHit(work.tabId, s.hit, info); return { page: p, pos: s.hit + 1, org: s.org, how: s.how, scroll: false }; }
      seen += s.n; prev = s.keys;
    }
    return { page: 0, seen: seen, adOnly: s && s.adHit >= 0 };
  }
  let seen = 0, mode = "url";
  for (let p = 1; p <= MAXP; p++) {
    await prog(lab + " " + p + "/" + MAXP + "페이지 확인 중… (상품 " + (seen + s.n) + "개째)");
    if (s.hit >= 0) { if (!ctx.shot) ctx.shot = await shotHit(work.tabId, s.hit, info); return { page: p, pos: s.hit + 1, org: s.org, how: s.how }; }
    seen += s.n;
    if (p === MAXP) break;
    const prev = s.keys;
    let s2 = null;
    if (mode === "url") {
      await nav(pageOf(base, site, dev, p + 1));
      s2 = await scanW(o);
      if (!s2 || s2.n === 0 || sameKeys(s2.keys, prev)) {
        /* 주소로 다음 페이지가 안 열리는 화면 → 페이지 번호 단추로 */
        mode = "click";
        await nav(base);
        s2 = await scanW(o);
        for (let q = 2; q <= p + 1 && s2; q++) {
          const before = s2.keys;
          if (!(await call(work.tabId, "clickPage", [q]))) { s2 = null; break; }
          await sleep(2500);
          s2 = await scanW(o);
          if (s2 && sameKeys(s2.keys, before)) { s2 = null; break; }
        }
      }
    } else {
      if (await call(work.tabId, "clickPage", [p + 1])) { await sleep(2500); s2 = await scanW(o); }
    }
    if (!s2 || s2.blocked || s2.n === 0 || sameKeys(s2.keys, prev)) return { page: 0, seen: seen, stuck: p };
    s = s2;
  }
  return { page: 0, seen: seen, adOnly: s.adHit >= 0 };
}

async function searchDev(ctx, dev, steps) {
  const log = [];
  for (const st of steps) {
    const [k, f] = st;
    const r = await look(ctx, dev, k, f);
    const lab = f ? "'" + k + "' + 가격" : "'" + k + "'";
    if (r.blocked) { log.push((HARD_BLOCK.test(work.blockSnip || "") ? "쇼핑몰이 접속을 일시적으로 막음 (자동 검색이 많다고 봄). 잠시 뒤 다시" : "쇼핑몰 보안 확인을 5분 안에 못 풀어서 멈춤") + " (화면: " + (work.blockSnip || "") + ")"); return { log: log, blocked: true }; }
    if (r.err) { log.push(lab + " " + r.err); continue; }
    if (r.nofilter) { log.push(lab + " 가격 필터가 안 들어가서 건너뜀"); continue; }
    if (r.page > 0 || r.pos > 0) return { found: Object.assign({ k: k, f: f }, r), log: log };
    log.push(lab + (r.empty ? (r.snip ? " 상품 칸을 못 읽음 (화면: " + r.snip + ")" : " 검색 결과 없음") : r.stuck ? " " + r.stuck + "페이지까지(다음 페이지로 못 넘어감) 상품 " + r.seen + "개" : " 상품 " + r.seen + "개") + (r.adOnly ? " (광고 자리에만 있음)" : ""));
  }
  return { log: log };
}
/* 위치는 'N페이지'만 (사용자 요청). 계속 내려가는 모바일 화면은 광고 뺀 순서로 페이지를 셈 (쿠팡 36개, 네이버 40개씩) */
let PER = 36;
const posText = r => !r ? "" : r.scroll ? Math.max(1, Math.ceil((r.org || r.pos) / PER)) + "페이지" : r.page + "페이지";
/* 가격 필터는 '가검40000' (가검 = 가격검색) */
const gageom = (lo, hi) => "가검" + (lo === hi ? lo : lo + "~" + hi);

/* ---------- 상품 위치 캡처 저장: 검색 화면에서 찾은 칸을 빨간 테두리로, 상품명·가격이 보이게 잘라서 다운로드 폴더에 (사용자 요청 10/21) ---------- */
const b64 = buf => { let s = ""; const a = new Uint8Array(buf); for (let i = 0; i < a.length; i += 0x8000) s += String.fromCharCode.apply(null, a.subarray(i, i + 0x8000)); return btoa(s); };
/* 썸네일·캡처 파일 이름 = 폼 제목 (생성기가 주소 뒤 &fn= 으로 넘김: '# 실링팬', '#택 과일쏙 대봉감', 사용자 요청 10/24). 2시간 안에 받은 이름을 씀 */
const fnOf = h => { const m = String(h || "").match(/(?:^|&)fn=([^&]+)/); try { return m ? decodeURIComponent(m[1]) : ""; } catch (e) { return ""; } };
async function keepFn(fn) { if (fn) await chrome.storage.local.set({ lastFn: { fn: fn, at: Date.now() } }); }
async function recentFn(info) {
  if (info && info.fn) return info.fn;
  const o = (await chrome.storage.local.get("lastFn")).lastFn;
  return o && Date.now() - o.at < 2 * 3600000 ? o.fn : "";
}
const fileSafe = s => String(s || "").replace(/[\\/:*?"<>|~%&{}$!'@+`=^]/g, " ").replace(/\s+/g, " ").trim().slice(0, 40).replace(/[.\s]+$/, "");
async function shotRect(tabId, rc, info) {
  if (!rc || !(rc.w > 0)) return null;
  const tab = await chrome.tabs.get(tabId);
  const back = tab.active ? 0 : (await chrome.tabs.query({ active: true, windowId: tab.windowId }))[0];
  if (!tab.active) { await chrome.tabs.update(tabId, { active: true }); await sleep(600); }
  let url = "";
  try { url = await chrome.tabs.captureVisibleTab(tab.windowId, { format: "png" }); }
  finally { if (back) chrome.tabs.update(back.id, { active: true }).catch(() => {}); }
  const bmp = await createImageBitmap(await (await fetch(url)).blob());
  const k = bmp.width / rc.vw, m = 10;
  const x = Math.max(0, (rc.x - m) * k), y = Math.max(0, (rc.y - m) * k);
  const w = Math.min(bmp.width - x, (rc.w + 2 * m) * k), h = Math.min(bmp.height - y, (rc.h + 2 * m) * k);
  const cv = new OffscreenCanvas(Math.round(w), Math.round(h));
  cv.getContext("2d").drawImage(bmp, x, y, w, h, 0, 0, w, h);
  const png = await cv.convertToBlob({ type: "image/png" });
  const safe = (info.name || "").replace(/[\\/:*?"<>|~#%&{}$!'@+`=^]/g, " ").replace(/\s+/g, " ").trim().slice(0, 30).replace(/[.\s]+$/, "");
  const ft = fileSafe(String(await recentFn(info)).replace("{판매처}", String(info.seller || "").replace(/\s+/g, "")));
  const fn = "체험단_썸네일/" + (ft ? ft : (safe ? safe + "_" : "") + (info.pid || "상품") + "_위치") + ".png";   /* 폼 제목만 (사용자 요청 10/24) */
  const data = "data:image/png;base64," + b64(await png.arrayBuffer());
  let fn2 = fn, id = null;
  try { id = await chrome.downloads.download({ url: data, filename: fn, conflictAction: "overwrite", saveAs: false }); }
  catch (e) { fn2 = "position_" + String(info.pid || "item").replace(/[^\w-]/g, "") + ".png"; id = await chrome.downloads.download({ url: data, filename: fn2, conflictAction: "overwrite", saveAs: false }); }   /* 폴더 이름이 안 되는 컴퓨터 */
  return id ? { t: "상품 위치 캡처 저장됨: 다운로드 폴더 › " + fn2 } : null;
}
async function shotHit(tabId, hit, info) {
  try { const rc = await call(tabId, "markRect", [hit]); return await shotRect(tabId, rc, info); } catch (e) { self.__shotErr = String((e && e.message) || e); return null; }
}

/* ---------- 썸네일 저장 ---------- */
async function saveThumb(info) {
  if (!info.img) return { t: "썸네일 주소를 못 찾았어요.", warn: true };
  const ext = ((info.img.match(/\.(png|jpe?g|webp|gif)(\?|$)/i) || [])[1] || "jpg").toLowerCase().replace("jpeg", "jpg");
  const safe = (info.name || "").replace(/[\\/:*?"<>|~#%&{}$!'@+`=^]/g, " ").replace(/\s+/g, " ").trim().slice(0, 30).replace(/[.\s]+$/, "");
  const ft = fileSafe(String(await recentFn(info)).replace("{판매처}", String(info.seller || "").replace(/\s+/g, "")));
  const fn = "체험단_썸네일/" + (ft ? ft : (safe ? safe + "_" : "") + info.pid) + "." + ext;
  try {
    let id = null, fn2 = fn;
    try { id = await chrome.downloads.download({ url: info.img, filename: fn, conflictAction: "overwrite", saveAs: false }); }
    catch (e) { fn2 = "thumbnails/thumb_" + info.pid + "." + ext; id = await chrome.downloads.download({ url: info.img, filename: fn2, conflictAction: "overwrite", saveAs: false }); }   /* 한글 이름이 안 되는 컴퓨터 */
    for (let i = 0; i < 40; i++) {
      await sleep(500);
      const [d] = await chrome.downloads.search({ id: id });
      if (!d) break;
      if (d.state === "complete") return { t: "썸네일 저장됨: 다운로드 폴더 › " + fn2 };
      if (d.state === "interrupted") return { t: "썸네일 저장 실패 (" + d.error + "). 결과 상자의 사진을 우클릭 → 이미지 저장", warn: true };
    }
    return { t: "썸네일 저장 중: 다운로드 폴더 › " + fn2 };
  } catch (e) { return { t: "썸네일 저장 실패 (" + ((e && e.message) || e) + "). 결과 상자의 사진을 우클릭 → 이미지 저장", warn: true }; }
}

/* ---------- 복사 (화면 밖 작은 문서에서) ---------- */
async function copyText(text, tabId) {
  pushGen({ text: text });
  if (tabId) { try { if (await call(tabId, "copy", [text])) return true; } catch (e) {} }
  try {
    try { await chrome.offscreen.createDocument({ url: "offscreen.html", reasons: ["CLIPBOARD"], justification: "결과 복사" }); } catch (e) {}
    const r = await chrome.runtime.sendMessage({ type: "copy", text: text });
    return !!(r && r.ok);
  } catch (e) { self.__copyErr = String((e && e.message) || e); return false; }
}
async function newer() {
  try { const r = await fetch(VER_URL + "?t=" + Date.now(), { cache: "no-store" }); const m = await r.json(); return m.version && m.version !== VERSION && cmpVer(m.version, VERSION) > 0 ? m.version : ""; } catch (e) { return ""; }
}
const cmpVer = (a, b) => { const x = a.split(".").map(Number), y = b.split(".").map(Number); for (let i = 0; i < Math.max(x.length, y.length); i++) { if ((x[i] || 0) !== (y[i] || 0)) return (x[i] || 0) - (y[i] || 0); } return 0; };

/* ---------- 전체 ---------- */
async function run(tab) {
  const tid = tab.id;
  if (/^https:\/\/(m?search)\.shopping\.naver\.com\//.test(tab.url || "")) return naverHere(tab);
  if (/^https:\/\/(www|m)\.coupang\.com\/(np|nm)\/search/.test(tab.url || "")) return coupangHere(tab);
  /* 올리브영: 상품 페이지·검색 화면 모두 북마크와 같은 코드(oy.js)로 */
  if (/^https?:\/\/([a-z]+\.)?(oliveyoung\.co\.kr|toss\.shopping|toss\.im)\//.test(tab.url || "")) { await chrome.scripting.executeScript({ target: { tabId: tid }, files: ["oy.js"] }); return; }
  let info = await call(tid, "readProduct").catch(() => null);
  /* 상품 화면이 아직 다 안 그려졌으면(상품명 빈칸) 최대 15초 기다렸다 다시 읽음 (11/1: 열고 2초 만에 읽어서 다 빈칸이었음) */
  for (let i = 0; i < 15 && info && !info.err && !info.name && /coupang\.com/.test(tab.url || ""); i++) { await sleep(1000); info = await call(tid, "readProduct").catch(() => info); }
  if (!info) { await ui(tid, { title: "상품 위치 찾기", msg: "이 화면은 읽을 수 없어요. 쿠팡·네이버·올리브영 상품 페이지에서 눌러 주세요." }); return; }
  if (info.err) { await ui(tid, { title: "상품 위치 찾기", msg: info.err }); return; }
  if (/사용권한이\s*없|접속이\s*제한|Access\s*Denied/i.test(info.name || "")) {
    await ui(tid, { title: "상품 페이지 오류", msg: "쿠팡에서 사용권한 없음/차단 오류가 떴어요. 상품 페이지를 직접 확인해 주세요." });
    return;
  }
  const site = info.site;
  if (site === "naver") return naverProduct(tab, info);
  if (site === "coupang") return coupangProduct(tab, info);
  PER = 36;
  const h = await tabHash(tab);
  if (fnOf(h)) { info.fn = fnOf(h); await keepFn(info.fn); }
  const hk = (h.match(/(?:^|&)kw=([^&]+)/) || [])[1], hp = Number((h.match(/(?:^|&)pr=(\d+)/) || [])[1] || 0);
  const kws = (hk ? decodeURIComponent(hk).split("|") : suggest(info.name)).map(x => x.trim()).filter(Boolean).slice(0, 4);
  const price = hp || info.price || 0;
  /* 가격 필터: 네이버는 그 가격 그대로(40,000~40,000), 쿠팡은 ±10% */
  const P = site === "naver" ? { lo: price, hi: price } : { lo: Math.floor(price * 0.9 / 100) * 100, hi: Math.ceil(price * 1.1 / 100) * 100 };
  const steps = [];
  kws.forEach(k => { steps.push([k, false]); if (price) steps.push([k, true]); });
  const head = "키워드: " + kws.join(" → ") + (hk ? "" : "\n(자동 추천 키워드예요. 의뢰서 키워드로 찾으려면 생성기의 [상품 페이지 열기]로 연 페이지에서 누르세요)") + (price ? "\n가격: " + price.toLocaleString("ko-KR") + "원" : "\n가격을 못 읽어서 가격 필터는 빼고 찾아요");
  const prog = curProg = t => ui(tid, { title: "상품 위치 찾는 중… (창을 닫지 마세요)", msg: head + "\n\n" + t });
  if (!kws.length) { await ui(tid, { title: "상품 위치 찾기", msg: "상품명을 못 읽어서 키워드를 못 만들었어요." }); return; }
  await prog("시작");
  const thumbP = null;   // 썸네일 대신 찾은 칸 캡처 (못 찾으면 썸네일)
  const verP = newer();
  const ctx = { site: site, info: info, P: P, prog: prog, plain: {} };
  await openWork();
  const pc = await searchDev(ctx, "pc", steps);
  /* 모바일은 PC에서 찾은 키워드·필터 그대로 (공지 한 줄로 둘 다 쓰게). PC에서 못 찾았으면 처음부터 */
  await mobile(true);
  const mo = pc.found ? await searchDev(ctx, "mo", [[pc.found.k, pc.found.f]]) : await searchDev(ctx, "mo", steps);
  await closeWork();
  const F = pc.found || mo.found;
  const mask = s => s && s.length > 8 ? s.slice(0, 4) + "***" + s.slice(-4) : s;
  const filt = F && F.f ? gageom(P.lo, P.hi) : "";
  const out = [
    "상품명 : " + info.name,
    "판매처 : " + info.seller,
    "상품번호 : " + info.pid + (info.item ? " - " + mask(info.item) : ""),
    info.opt ? "옵션 : " + info.opt : "",
    price ? "가격 : " + price.toLocaleString("ko-KR") + "원" : "",
    info.optPrices && info.optPrices.length ? "옵션별 가격 : " + info.optPrices.map(x => x.o + " " + x.p.toLocaleString("ko-KR") + "원").join(" / ") : "",
    info.ship ? "배송비 : " + info.ship : "",
    info.rocket ? "배송 : 로켓배송" : "",
    F ? "찾은 키워드 : " + F.k : "",
    filt ? "필터 : " + filt : "",
    "PC 위치 : " + (pc.found ? posText(pc.found) : "못 찾음"),
    "모바일 위치 : " + (mo.found ? posText(mo.found) : "못 찾음"),
    info.img ? "썸네일 : " + info.img : ""
  ].filter(Boolean).join("\n");
  const notes = [];
  if (!pc.found && pc.log.length) notes.push({ t: "PC 확인한 것: " + pc.log.join(" / "), warn: true });
  if (!mo.found && mo.log.length) notes.push({ t: "모바일 확인한 것: " + mo.log.join(" / "), warn: true });
  [pc.found, mo.found].forEach((r, i) => { if (r && r.how === "상품명") notes.push({ t: (i ? "모바일" : "PC") + ": 상품명으로 찾았어요 (스토어 이름은 화면에 없었음)" }); });
  if (info.img) {
    const st = await saveThumb(info);
    if (st) notes.push(st);
  }
  if (ctx.shot) notes.push(ctx.shot);
  const nv = await verP;
  if (nv) notes.push({ t: "새 버전(" + nv + ")이 있어요. 생성기에서 확장 프로그램을 다시 받아 바꿔 주세요.", warn: true });
  if (autoTab !== tid) { try { await chrome.windows.update(tab.windowId, { focused: true }); await chrome.tabs.update(tid, { active: true }); } catch (e) {} }
  const copied = await copyText(out, tid);
  const big = (F ? "키워드 : " + F.k + "\n" : "") + "PC " + (filt && pc.found ? filt + " " : "") + (pc.found ? posText(pc.found) : "못 찾음") + "\n모바일 " + (filt && mo.found ? filt + " " : "") + (mo.found ? posText(mo.found) : "못 찾음");
  await ui(tid, { title: copied ? "복사됐어요. 생성기 '상품 정보 붙여넣기' 칸에 Ctrl+V" : "복사를 눌러서 생성기 '상품 정보 붙여넣기' 칸에 붙여넣으세요", big: big, out: out, copied: copied, notes: notes, img: info.img });
  return out;
}

/* ================= 쿠팡 (1.6.0: 자동 검색 없이, 지금 화면만 읽기) ================= */
const cpMask = s => s && s.length > 8 ? s.slice(0, 4) + "***" + s.slice(-4) : s;
const cpInfoLines = (info, price) => [
  "상품명 : " + info.name,
  "판매처 : " + (info.seller || ""),
  "상품번호 : " + info.pid + (info.item ? " - " + cpMask(info.item) : ""),
  info.opt ? "옵션 : " + info.opt : "",
  price ? "가격 : " + price.toLocaleString("ko-KR") + "원" : "",
  info.optPrices && info.optPrices.length ? "옵션별 가격 : " + info.optPrices.map(x => x.o + " " + x.p.toLocaleString("ko-KR") + "원").join(" / ") : "",
  info.ship ? "배송비 : " + info.ship : "",
  info.rocket ? "배송 : 로켓배송" : "",
  info.img ? "썸네일 : " + info.img : ""
].filter(Boolean);
/* 지금 화면 위치 글자: PC는 주소의 page(=그 화면 페이지), 모바일(계속 내려가는 화면)은 광고 뺀 순서 ÷ 36 */
function cpPos(h, s, mob) {
  const page = mob ? Math.max(1, Math.ceil((s.org || s.hit + 1) / 36)) : (h.page || 1);
  const filt = h.lo && h.hi ? gageom(h.lo, h.hi) : "";
  return { page: page, filt: filt, line: (mob ? "모바일 위치 : " : "PC 위치 : ") + page + "p" };
}
async function coupangProduct(tab, info) {
  const tid = tab.id;
  const h = await tabHash(tab);
  if (fnOf(h)) { info.fn = fnOf(h); await keepFn(info.fn); }
  const hp = Number((h.match(/(?:^|&)pr=(\d+)/) || [])[1] || 0);
  const price = hp || info.price || 0;
  /* 검색 화면에서 찾을 상품 (상품번호로 찾음). 상품마다 기억 + 마지막 것 */
  const t = { pid: info.pid, name: info.name, seller: info.seller, price: price, at: Date.now() };
  const st = await chrome.storage.local.get("cpTargets").catch(() => ({}));
  const all = Object.assign({}, st.cpTargets || {}); all[info.pid] = t;
  Object.keys(all).filter(k => Date.now() - (all[k].at || 0) > 3 * 86400000).forEach(k => delete all[k]);
  await chrome.storage.local.set({ cpTarget: t, cpTargets: all });
  const out = cpInfoLines(info, price).join("\n");
  const notes = [];
  if (!info.seller) notes.push({ t: "판매처를 못 읽었어요" + (info.sellerHint ? " (화면: " + info.sellerHint + ")" : "") + " → 판매처 칸을 직접 채워 주세요", warn: true });
  if (info.img) { const sv = await saveThumb(info); if (sv) notes.push(sv); }
  const nv = await newer();
  if (nv) notes.push({ t: "새 버전(" + nv + ")이 있어요. 생성기에서 확장 프로그램을 다시 받아 바꿔 주세요.", warn: true });
  const copied = await copyText(out, tid);
  const how = "위치: 생성기 [쿠팡에서 검색] → 열린 쿠팡 검색 화면에서 확장 아이콘(Alt+Shift+F). 없으면 쿠팡 '다음 페이지' 누르고 한 번 더";
  pushGen({ status: "상품 정보 넣었어요 ✓ " + how + (info.seller ? "" : " / ⚠ 판매처를 못 읽었어요" + (info.sellerHint ? " (화면: " + info.sellerHint + ")" : "")) });
  await call(tid, "box", [{ title: copied ? "상품 정보 복사됨 (생성기에도 넣었어요)" : "상품 정보 (복사를 눌러 생성기에 붙여넣기)", out: out, copied: copied, img: info.img,
    msg: "쿠팡은 확장이 검색 화면을 혼자 열면 막아서(11/1), 위치는 검색 화면에서 확인해요.\n" + how, notes: notes }]).catch(() => null);
  return out;
}
/* 지금 보고 있는 쿠팡 검색 화면에서 찾기 (화면을 넘기거나 새로 열지 않음) */
async function coupangHere(tab) {
  const tid = tab.id;
  const hh = await tabHash(tab);
  const hpid = (hh.match(/(?:^|&)pid=(\d+)/) || [])[1] || "";
  const st = await chrome.storage.local.get(["cpTarget", "cpTargets"]).catch(() => ({}));
  const t = hpid ? ((st.cpTargets || {})[hpid] || { pid: hpid, name: "", seller: "" }) : st.cpTarget;
  if (!t || !t.pid) { await ui(tid, { title: "상품 위치 찾기", msg: "어떤 상품을 찾을지 몰라요. 먼저 생성기 [자동 가져오기](또는 쿠팡 상품 페이지에서 아이콘)를 한 번 해 주세요." }); return; }
  const mob = /^https:\/\/m\./.test(tab.url || "");
  await ui(tid, { title: "이 화면에서 찾는 중…", msg: "상품번호 " + t.pid + (t.name ? " (" + t.name.slice(0, 30) + ")" : "") });
  const s = await call(tid, "scan", [{ pid: t.pid, nm: t.name, st: t.seller, scroll: mob, max: 200 }]);
  if (!s || s.error) { await ui(tid, { title: "화면을 못 읽었어요", msg: (s && s.error) || "", notes: [{ t: "화면: " + ((s && s.snip) || ""), warn: true }] }); return; }
  if (s.blocked) { await ui(tid, { title: "쿠팡이 이 화면을 막았어요", msg: "새로고침하지 말고 몇 분 뒤에 쿠팡에서 다시 검색해 주세요." }); return; }
  const h = await call(tid, "here");
  const P = cpPos(h, s, mob);
  if (s.hit >= 0) {
    const shot = await shotHit(tid, s.hit, t);
    const out = [h.query ? "찾은 키워드 : " + h.query : "", P.filt ? "필터 : " + P.filt : "", s.similar ? "주의 : 비슷한 상품 많음" : "", P.line].filter(Boolean).join("\n");
    pushGen({ text: out });
    pushGen({ status: "위치 넣었어요 ✓ " + (mob ? "모바일 " : "PC ") + (P.filt ? P.filt + " " : "") + P.page + "p" });
    await call(tid, "box", [{ title: "찾았어요! 생성기 위치 칸에 넣었어요", big: "키워드 : " + (h.query || "?") + "\n" + (mob ? "모바일 " : "PC ") + (P.filt ? P.filt + " " : "") + P.page + "p", out: out, copied: false,
      notes: [{ t: "분홍 테두리가 찾은 상품이에요 (광고 빼고 " + s.org + "번째)." }, shot, mob ? null : { t: "모바일 위치는 휴대폰에서 북마크로 확인해 주세요." }].filter(Boolean) }]).catch(() => null);
    return out;
  }
  const where = mob ? "이 화면" : "이 화면(" + (h.page || 1) + "페이지)";
  pushGen({ status: where + "에는 없어요. 쿠팡 '다음 페이지'를 누르고 아이콘을 한 번 더 눌러 주세요" });
  await ui(tid, { title: where + "에는 없어요", msg: "검색어 '" + (h.query || "?") + "'" + (P.filt ? ", " + P.filt : "") + ", 상품 " + s.n + "개 확인" + (s.adHit >= 0 ? " (광고 칸에만 있었어요)" : "") + ".\n쿠팡 화면 아래 '다음 페이지'를 직접 누르고, 다 뜨면 아이콘을 한 번 더 눌러 주세요.",
    notes: [{ t: "찾는 상품: 상품번호 " + t.pid + (t.name ? " / " + t.name.slice(0, 45) : "") + " (다른 상품이면 생성기에서 그 상품의 [쿠팡에서 검색]으로 열어 주세요)" }] });
}

/* ================= 네이버 (자동 넘기기 없이, 지금 화면만 읽기) ================= */
const mask2 = s => s && s.length > 8 ? s.slice(0, 4) + "***" + s.slice(-4) : s;
const infoLines = t => ["상품명 : " + t.name, "판매처 : " + t.seller, "상품번호 : " + t.pid + (t.item ? " - " + mask2(t.item) : ""), t.opt ? "옵션 : " + t.opt : "", t.price ? "가격 : " + t.price.toLocaleString("ko-KR") + "원" : "", t.ship ? "배송비 : " + t.ship : "", t.img ? "썸네일 : " + t.img : ""].filter(Boolean);
const nvSearchUrl = (k, mob) => (mob ? "https://msearch.shopping.naver.com" : "https://search.shopping.naver.com") + "/search/all?query=" + encodeURIComponent(k);
const won = n => Number(n).toLocaleString("ko-KR");

async function naverProduct(tab, info) {
  const h = await tabHash(tab);
  if (fnOf(h)) { info.fn = fnOf(h); await keepFn(info.fn); }
  const hk = (h.match(/(?:^|&)kw=([^&]+)/) || [])[1], hp = Number((h.match(/(?:^|&)pr=(\d+)/) || [])[1] || 0);
  const kws = (hk ? decodeURIComponent(hk).split("|") : suggest(info.name)).map(x => x.trim()).filter(Boolean).slice(0, 4);
  const price = hp || info.price || 0;
  const t = Object.assign({}, info, { kws: kws, price: price, at: Date.now() });
  await chrome.storage.local.set({ nvTarget: t });
  const thumb = { t: "썸네일 대신: 검색 화면에서 찾으면 그 칸을 캡처해서 저장해요." };
  const out = infoLines(t).join("\n");
  const copied = await copyText(out, tab.id);
  await ui(tab.id, { title: "상품 정보 " + (copied ? "복사됨" : "") + " · 네이버 검색 탭을 열었어요", out: out, copied: copied, img: info.img,
    msg: "네이버는 자동으로 여러 페이지를 넘기면 접속을 막아서, 검색 화면은 한 화면씩 확인해요.\n새 탭의 검색 화면에서 상품을 찾아 표시해 드려요.\n순서: " + kws.map(k => "'" + k + "'" + (price ? " → '" + k + "' + 가격 " + won(price) + "원" : "")).join(" → "),
    notes: [thumb] });
  const nt = await chrome.tabs.create({ url: nvSearchUrl(kws[0], false), index: tab.index + 1, active: true });
  await waitComplete(nt.id, 25000);
  await sleep(2000);
  return naverHere(nt);
}

/* 지금 보고 있는 네이버 검색 화면에서 찾기 */
async function naverHere(tab) {
  const tid = tab.id;
  const { nvTarget: t } = await chrome.storage.local.get("nvTarget");
  if (!t) { await ui(tid, { title: "상품 위치 찾기", msg: "먼저 네이버 상품 페이지(스마트스토어)에서 아이콘을 눌러 주세요. 그 상품을 이 화면에서 찾아요." }); return; }
  await ui(tid, { title: "이 화면에서 찾는 중…", msg: "아래로 내리면서 '" + t.name.slice(0, 30) + "'를 찾고 있어요." });
  const mob = /msearch|^https:\/\/m\./.test(tab.url || "");
  const s = await call(tid, "scan", [{ pid: t.pid, nm: t.name, st: t.seller, scroll: mob, max: 200 }]);
  if (!s || s.error) { await ui(tid, { title: "화면을 못 읽었어요", msg: (s && s.error) || "" , notes: [{ t: "화면: " + ((s && s.snip) || ""), warn: true }] }); return; }
  if (s.blocked) {
    await ui(tid, { title: "네이버가 접속을 막아 둔 상태예요", msg: "자동 검색이 많았다고 보고 잠깐 막은 거예요. 시간이 지나면 풀려요(보통 몇 시간 안).\n그동안은 자동으로 넘기지 말고, 풀린 뒤에 이 화면에서 아이콘을 다시 눌러 주세요.\n계속 안 풀리면 화면의 '원클릭 진단'을 눌러 보세요." });
    return;
  }
  const h = await call(tid, "here");
  const plan = [];
  t.kws.forEach(k => { plan.push([k, false]); if (t.price) plan.push([k, true]); });
  const filtered = !!(h.lo && h.hi);
  if (s.hit >= 0) {
    const shot = await shotHit(tid, s.hit, t);
    const pos = mob ? Math.max(1, Math.ceil(s.org / 40)) + "페이지" : h.page + "페이지";
    const out = infoLines(t).concat([h.query ? "찾은 키워드 : " + h.query : "", filtered ? "필터 : " + gageom(h.lo, h.hi) : "", s.similar ? "주의 : 비슷한 상품 많음" : "", (mob ? "모바일 위치 : " : "PC 위치 : ") + pos]).filter(Boolean).join("\n");
    const copied = await copyText(out, tid);
    await ui(tid, { title: copied ? "찾았어요! 복사됐어요. 생성기 '상품 정보 붙여넣기' 칸에 Ctrl+V" : "찾았어요! 복사를 눌러 생성기에 붙여넣으세요", big: "키워드 : " + h.query + "\n위치 : " + (filtered ? gageom(h.lo, h.hi) + " " : "") + pos + (s.similar ? "\n(비슷한 상품 많음 → 공지에 '판매처, 가격 보고 구매' 안내가 붙어요)" : ""), out: out, copied: copied,
      notes: [{ t: "분홍 테두리가 찾은 상품이에요." + (s.how === "상품명" ? " (상품명으로 찾음, 스토어 이름은 화면에 없었음)" : "") }, mob ? null : { t: "모바일 위치는 휴대폰에서 북마크로 확인해 주세요." }].filter(Boolean) });
    return;
  }
  /* 없으면 다음 할 일 단추 */
  const idx = plan.findIndex(p => p[0] === h.query && p[1] === filtered);
  const nextStep = plan[(idx >= 0 ? idx : -1) + 1];
  const actions = [];
  if (!mob && h.page < MAXP) actions.push({ label: "다음 페이지 (" + (h.page + 1) + "페이지) 보고 다시 찾기", act: "next" });
  if (nextStep) actions.push(nextStep[1] ? { label: "가격 " + won(t.price) + "~" + won(t.price) + "원 넣고 다시 찾기", act: "price" } : { label: "'" + nextStep[0] + "' 검색하고 다시 찾기", act: "kw:" + nextStep[0], color: "#5b2a86" });
  await ui(tid, { title: "이 화면" + (mob ? "" : "(" + h.page + "페이지)") + "에는 없어요", msg: "검색어 '" + (h.query || "?") + "'" + (filtered ? ", 가격 " + won(h.lo) + "~" + won(h.hi) + "원" : "") + ", 상품 " + s.n + "개 확인" + (s.adHit >= 0 ? " (광고 자리에만 있어요)" : "") + (s.n === 0 ? "\n화면: " + (s.snip || "") : ""),
    actions: actions, notes: [{ t: "단추를 누르면 한 화면만 넘기고 다시 찾아요. 너무 빨리 여러 번 누르지 마세요(네이버가 막아요)." },
      { t: "찾는 상품: " + String(t.name || "").slice(0, 45) + " / " + (t.seller || "?") + " (다른 상품이면 그 상품 페이지에서 아이콘을 먼저 눌러 주세요)" },
      s.near && s.near.sc >= 0.5 ? { t: "가장 비슷한 칸(" + s.near.i + "번째, 상품명 " + Math.round(s.near.sc * 100) + "% 같음" + (s.near.st ? ", 스토어 같음" : ", 스토어 다름/안 보임") + (s.near.ad ? ", 광고" : "") + "): " + s.near.t + "\n이게 맞는 상품이면 이 화면을 캡처해서 알려 주세요.", warn: true } : null].filter(Boolean) });
}

async function naverAct(tab, act) {
  const tid = tab.id;
  const { nvTarget: t } = await chrome.storage.local.get("nvTarget");
  const h = await call(tid, "here");
  const mob = h && h.mob;
  await ui(tid, { title: "넘기는 중…", msg: "" });
  if (act === "next") {
    const ok = await call(tid, "clickPage", [h.page + 1]);
    if (!ok) { const u = new URL(tab.url); u.searchParams.set("pagingIndex", h.page + 1); const p = waitComplete(tid, 25000); await chrome.tabs.update(tid, { url: u.href }); await p; }
  } else if (act === "price") {
    const ok = await call(tid, "priceUI", [t.price, t.price]);
    if (!ok) { const u = new URL(tab.url); u.searchParams.set("minPrice", t.price); u.searchParams.set("maxPrice", t.price); u.searchParams.delete("pagingIndex"); const p = waitComplete(tid, 25000); await chrome.tabs.update(tid, { url: u.href }); await p; }
  } else if (act.indexOf("kw:") === 0) {
    const p = waitComplete(tid, 25000); await chrome.tabs.update(tid, { url: nvSearchUrl(act.slice(3), mob) }); await p;
  }
  await sleep(3500);
  const [cur] = await chrome.tabs.query({ active: true, lastFocusedWindow: true });
  return naverHere(cur && cur.id === tid ? cur : await chrome.tabs.get(tid));
}
